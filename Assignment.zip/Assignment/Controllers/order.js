import orderModal from "../Modal/order.js"
import date from 'date-and-time';

export async function createOrder(req, res) {
    try {
        const { orderId, item_name, cost, order_date, delivery_date } = req.body;
        if (!orderId || !item_name || !cost) {
            return res.status(400).json({ errorMessage: "Please enter all required fields" });
        }
        const id = await orderModal.find({ orderId: orderId })
        if (id.length) {
            return res.status(400).json({ errorMessage: `OrderId ${orderId} is already exist!` })
        } else {
            const { orderId, item_name, cost, order_date, delivery_date } = req.body;
            const orderDate = date.format((new Date(order_date)),
            'YYYY/MM/DD HH:mm:ss');
            const deliveryDate = date.format((new Date(delivery_date)),
            'YYYY/MM/DD HH:mm:ss');
            const saveOrder = new orderModal({
                orderId: orderId,
                item_name: item_name,
                cost: cost,
                order_date: orderDate,
                delivery_date: deliveryDate
            });
            const result = await saveOrder.save();
            console.log(result);
            res.send(result);
        }
    } catch (error) {
        console.log(error);
        res.send('Someting went wrong');
    }
}

export async function searchOrder(req, res){
    try {
        const result = await orderModal.findOne({orderId : req.params.orderId});
        if(!result){
            const saveOrder = new orderModal({
                orderId: orderId,
                item_name: item_name,
                cost: cost,
                order_date: order_date,
                delivery_date: delivery_date
            });
            const result = await saveOrder.save();
            console.log(result);
            res.send(result);
        }
        res.send(result);
    } catch (error) {
        console.log(Error)
    }
}

export default async function updateOrder(req, res) {
    try {
        const orderId = req.params.id;
        const result = await orderModal.findOneAndUpdate(orderId, req.body);
        console.log(result);
        res.send(result)
    } catch (error) {
        console.log(error);
        res.send('Something went wrong');
    }
}
export async function listOrder (req,res){
    try {
        const result = await orderModal.find();
        console.log(result);
        res.send(result);
    } catch (error) {
        console.log(Error)
    }
}
export async function deleteOrder(req,res) {
    try {
        var orderId = (req.params.orderId);
       console.log(req.params.orderId);
        const result = await orderModal.deleteOne({'orderId' : req.params.orderId})
        console.log(result);
        res.send(result)
    } catch (error) {
        console.log(error);
        res.send('Something went wrong');
    }
}
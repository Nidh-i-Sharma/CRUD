import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
    orderId :{
        type :Number,
        required : true
    },
    item_name:{
        type :String,
        required : true
    },
    cost:{
        type :Number,
    },
    order_date:{
        type :Date,
    },
    delivery_date:{
        type :Date,
    }
})

const orderModal = mongoose.model('order' , orderSchema)
export default orderModal
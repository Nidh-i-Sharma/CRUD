import express from 'express';
import connectDB from './config/db.js';
import  { deleteOrder, searchOrder , createOrder, listOrder}   from './Controllers/order.js'
import  updateOrder   from './Controllers/order.js'
// import { createOrder, listOrder,searchOrder,updateOrder,deleteOrderByOrderId } from './Controllers/order.js';
const app = express();

const port = '4200';

connectDB().then((res) =>{
    console.log(res);
});




/*assuming an express app is declared here*/
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.get('/order/search/:orderId', searchOrder)
app.post('/order/search/:orderId', searchOrder)
app.post('/order/create', createOrder)
app.post('/order/update/:id', updateOrder)
app.get('/order/list', listOrder)
app.delete('/order/delete/:orderId', deleteOrder)

app.listen(port ,  (req,res)=>{
    console.log(`Server started at http://localhost:${port}`);
})

